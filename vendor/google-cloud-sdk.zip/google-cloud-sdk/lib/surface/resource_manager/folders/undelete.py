# Copyright 2016 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Command to undelete a folder."""

import textwrap

from googlecloudsdk.api_lib.resource_manager import folders
from googlecloudsdk.calliope import base
from googlecloudsdk.command_lib.resource_manager import flags
from googlecloudsdk.command_lib.resource_manager import folders_base
from googlecloudsdk.core import log


@base.Hidden
@base.ReleaseTracks(base.ReleaseTrack.ALPHA)
class Undelete(folders_base.FolderCommand):
  """Undelete a folder.

  Undeletes the folder with the given folder ID.

  This command can fail for the following reasons:
  * There is no folder with the given ID.
  * The active account does not have Owner or Editor permissions for the
    given folder.
  * When the folder to be undeleted has the same display name as an active
    folder under this folder's parent.
  """
  detailed_help = {
      'EXAMPLES': textwrap.dedent("""\
          The following command undeletes the folder with the ID
          `3589215982`:

            $ {command} 3589215982
    """),
  }

  @staticmethod
  def Args(parser):
    flags.FolderIdArg('you want to undelete.').AddToParser(parser)

  def Run(self, args):
    service = folders.FoldersService()
    messages = folders.FoldersMessages()
    restored = service.Undelete(
        messages.CloudresourcemanagerFoldersUndeleteRequest(
            foldersId=args.id))
    log.RestoredResource(restored)
